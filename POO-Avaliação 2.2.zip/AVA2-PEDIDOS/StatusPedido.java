public enum StatusPedido {
    EM_PROCESSAMENTO,
    ENVIADO,
    ENTREGUE,
    CANCELADO
}

